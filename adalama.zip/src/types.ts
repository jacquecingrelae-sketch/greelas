export interface Module {
  nom: string;
  progression: number;
}

export interface Formation {
  id: string | number;
  titre: string;
  description: string;
  prix: number;
  duree: string;
  niveau: string;
  image: string;
  categorie: string;
  modules: Module[];
}

export interface User {
  id: string;
  nom: string;
  prenom: string;
  email: string;
  telephone?: string;
  role: 'student' | 'admin';
  dateInscription: string;
}

export interface Candidature {
  id: string;
  userId: string;
  nom: string;
  prenom: string;
  email: string;
  formation: string;
  niveau: string;
  statut: 'en_attente' | 'admis' | 'refuse';
  lettre?: string;
  cvUrl?: string;
  date: string;
}

export interface Message {
  id: string;
  senderName: string;
  senderRole: 'student' | 'tutor';
  receiverName: string;
  text: string;
  date: string;
}

export interface Payment {
  id: string;
  userId: string;
  formationId: string | number;
  amount: number;
  date: string;
  status: 'completed' | 'pending';
}

export interface TimetableEvent {
  id: string;
  courseTitle: string;
  professorName: string;
  dayOfWeek: string; // e.g., 'Lundi', 'Mardi', etc.
  startTime: string; // e.g., '09:00'
  endTime: string;   // e.g., '11:00'
  room: string;      // e.g., 'Amphi B' or 'Classe Virtuelle'
  color: string;     // Tailwind brand badge colors
  filiere?: string;  // e.g., 'informatique', 'gestion', 'droit', 'marketing', or 'Tous'
}

export interface AttendanceRecord {
  id: string;
  userId: string;
  userName: string;
  date: string;      // e.g., '2026-05-29'
  courseTitle: string;
  status: 'present' | 'absent' | 'late';
  signed: boolean;   // Signed by student
  timeSigned?: string;
}

export interface Receipt {
  id: string;
  paymentId: string;
  userId: string;
  userName: string;
  amount: number;
  date: string;
  receiptNumber: string;
  courseTitle: string;
  paymentMethod: string;
}

export interface DashboardStats {
  totalEtudiants: number;
  totalCandidatures: number;
  totalAdmis: number;
  totalCertifies: number;
  totalRevenus: number;
  enAttente: number;
}
