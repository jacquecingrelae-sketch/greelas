import { promises as fs } from 'fs';
import path from 'path';
import mongoose from 'mongoose';
import { User, Formation, Candidature, Message, Payment, DashboardStats, TimetableEvent, AttendanceRecord, Receipt } from '../src/types';

const DATA_FILE = path.join(process.cwd(), 'local_database.json');
const MONGO_URI = process.env.MONGO_URI;

export interface DBConfig {
  type: 'MongoDB' | 'LocalJSON';
  status: 'connected' | 'disconnected';
  uri?: string;
  error?: string;
}

export let dbConfig: DBConfig = {
  type: 'LocalJSON',
  status: 'connected',
};

// --- Standard Seed Data ---
const DEFAULT_FORMATIONS: Formation[] = [
  {
    id: 1,
    titre: 'Informatique & Génie Logiciel',
    description: 'Développement d\'applications web, mobiles et cloud. Apprentissage intensif des architectures modernes, React, Node.js et bases de données.',
    prix: 2500,
    duree: '3 ans',
    niveau: 'Licence',
    image: '💻',
    categorie: 'informatique',
    modules: [
      { nom: 'Conception Web (React)', progression: 0 },
      { nom: 'Backend & APIs (Express/Node)', progression: 0 },
      { nom: 'Bases de Données (MongoDB)', progression: 0 },
      { nom: 'Architecture Logicielle', progression: 0 },
      { nom: 'Introduction à l\'Intelligence Artificielle', progression: 0 }
    ]
  },
  {
    id: 2,
    titre: 'Gestion d\'Entreprise & Management',
    description: 'Management, finance, comptabilité et entrepreneuriat. Pour devenir un leader capable de structurer et d\'accélérer les projets d\'entreprise.',
    prix: 2200,
    duree: '3 ans',
    niveau: 'Licence',
    image: '📊',
    categorie: 'gestion',
    modules: [
      { nom: 'Comptabilité Générale', progression: 0 },
      { nom: 'Marketing & Stratégie', progression: 0 },
      { nom: 'Ressources Humaines', progression: 0 },
      { nom: 'Droit commercial et fiscal', progression: 0 }
    ]
  },
  {
    id: 3,
    titre: 'Droit des Affaires Internationales',
    description: 'Droit civil, des sociétés et négociations internationales. Maîtrisez les contrats et protections juridiques pour les organisations globales.',
    prix: 2800,
    duree: '4 ans',
    niveau: 'Master',
    image: '⚖️',
    categorie: 'droit',
    modules: [
      { nom: 'Droit civil & des Obligations', progression: 0 },
      { nom: 'Droit pénal des Affaires', progression: 0 },
      { nom: 'Droit international comparé', progression: 0 }
    ]
  },
  {
    id: 4,
    titre: 'Marketing Digital & Communication',
    description: 'SEO, SEM, publicité en ligne et stratégies réseaux sociaux. Apprenez à concevoir et piloter la croissance digitale des marques.',
    prix: 2000,
    duree: '2 ans',
    niveau: 'Master',
    image: '📱',
    categorie: 'marketing',
    modules: [
      { nom: 'SEO & Content Marketing', progression: 0 },
      { nom: 'SEM & Social Ads', progression: 0 },
      { nom: 'Stratégie de Contenu', progression: 0 },
      { nom: 'Web Analytics & Tracking', progression: 0 }
    ]
  },
  {
    id: 5,
    titre: 'Data Science & Big Data',
    description: 'Statistiques avancées, Python, Machine Learning et data visualization. Devenez un expert de l\'analyse prédictive et des données.',
    prix: 3000,
    duree: '2 ans',
    niveau: 'Master',
    image: '📈',
    categorie: 'informatique',
    modules: [
      { nom: 'Programmation Python pour la Data', progression: 0 },
      { nom: 'Algorithmes de Machine Learning', progression: 0 },
      { nom: 'Deep Learning & NLP', progression: 0 },
      { nom: 'Data Visualization & Reporting', progression: 0 }
    ]
  }
];

const DEFAULT_USERS: any[] = [
  {
    id: 'admin1',
    nom: 'Grela',
    prenom: 'ELSON Jacquecin',
    email: 'admin@univ-online.fr',
    telephone: '+33 6 45 89 23 10',
    password: 'Admin123!',
    role: 'admin',
    dateInscription: new Date().toISOString()
  },
  {
    id: 'student1',
    nom: 'Martin',
    prenom: 'Gre Las',
    email: 'pierre.martin@univ-online.fr',
    telephone: '+33 7 12 34 56 78',
    password: 'Student123!',
    role: 'student',
    dateInscription: new Date().toISOString(),
    formationsInscrites: [
      {
        formationId: 1,
        modules: [
          { nom: 'Conception Web (React)', progression: 60 },
          { nom: 'Backend & APIs (Express/Node)', progression: 40 },
          { nom: 'Bases de Données (MongoDB)', progression: 10 },
          { nom: 'Architecture Logicielle', progression: 0 },
          { nom: 'Introduction à l\'Intelligence Artificielle', progression: 0 }
        ]
      }
    ]
  }
];

const DEFAULT_MESSAGES: Message[] = [
  {
    id: 'msg1',
    senderName: 'Prof. Martin',
    senderRole: 'tutor',
    receiverName: 'ELSON Jacquecin Grela',
    text: 'Bonjour ! Bienvenue sur UNIV-ONLINE. Je suis votre professeur référent pour les cours d\'Informatique. Comment se déroule votre rentrée ?',
    date: new Date(Date.now() - 3600000 * 2).toISOString()
  },
  {
    id: 'msg2',
    senderName: 'Administration',
    senderRole: 'tutor',
    receiverName: 'ELSON Jacquecin Grela',
    text: 'Votre dossier de candidature a bien été enregistré. N\'hésitez pas à nous envoyer votre lettre de motivation si ce n\'est pas déjà fait.',
    date: new Date(Date.now() - 3600000 * 4).toISOString()
  }
];

const DEFAULT_CANDIDATURES: Candidature[] = [
  {
    id: 'cand1',
    userId: 'student1',
    nom: 'Martin',
    prenom: 'Gre Las',
    email: 'pierre.martin@univ-online.fr',
    formation: 'informatique',
    niveau: 'licence3',
    statut: 'admis',
    lettre: 'Je souhaite vivement me réorienter vers le développement web pour donner suite à mes projets personnels.',
    date: new Date(Date.now() - 86400000 * 3).toISOString()
  }
];

const DEFAULT_PAYMENTS: Payment[] = [
  {
    id: 'pay1',
    userId: 'student1',
    formationId: 1,
    amount: 2500,
    date: new Date(Date.now() - 86400000 * 2).toISOString(),
    status: 'completed'
  }
];

const DEFAULT_TIMETABLES: TimetableEvent[] = [
  { id: 't1', courseTitle: 'Conception Web (React)', professorName: 'Prof. Martin', dayOfWeek: 'Lundi', startTime: '09:00', endTime: '11:00', room: 'Amphi d\'E-learning', color: 'blue', filiere: 'informatique' },
  { id: 't2', courseTitle: 'Backend & APIs (Express/Node)', professorName: 'Prof. Martin', dayOfWeek: 'Mardi', startTime: '14:00', endTime: '16:30', room: 'Salle Virtuelle B', color: 'indigo', filiere: 'informatique' },
  { id: 't3', courseTitle: 'Marketing & Stratégie', professorName: 'Prof. Dubois', dayOfWeek: 'Mercredi', startTime: '10:00', endTime: '12:00', room: 'Amphi d\'E-learning', color: 'amber', filiere: 'marketing' },
  { id: 't4', courseTitle: 'Bases de Données (MongoDB)', professorName: 'Prof. Martin', dayOfWeek: 'Jeudi', startTime: '11:00', endTime: '13:00', room: 'Salle Informatique 301', color: 'emerald', filiere: 'informatique' },
  { id: 't5', courseTitle: 'Introduction à l\'Intelligence Artificielle', professorName: 'Prof. Martin', dayOfWeek: 'Vendredi', startTime: '15:00', endTime: '17:00', room: 'Amphi d\'Honneur', color: 'violet', filiere: 'informatique' },
  { id: 't6', courseTitle: 'Management des Équipes & Leadership', professorName: 'Prof. Dubois', dayOfWeek: 'Lundi', startTime: '14:00', endTime: '16:00', room: 'Salle Virtuelle C', color: 'violet', filiere: 'gestion' },
  { id: 't7', courseTitle: 'Contrôle de Gestion Financière', professorName: 'Prof. Dubois', dayOfWeek: 'Mercredi', startTime: '14:00', endTime: '16:30', room: 'Salle d\'Études 204', color: 'amber', filiere: 'gestion' },
  { id: 't8', courseTitle: 'Droit des Sociétés & Contrats', professorName: 'Prof. Laurent', dayOfWeek: 'Mardi', startTime: '09:00', endTime: '11:30', room: 'Amphi de Droit', color: 'violet', filiere: 'droit' },
  { id: 't9', courseTitle: 'Propriété Intellectuelle & Numérique', professorName: 'Prof. Laurent', dayOfWeek: 'Vendredi', startTime: '10:00', endTime: '12:00', room: 'Salle d\'Études 202', color: 'amber', filiere: 'droit' },
  { id: 't10', courseTitle: 'E-Commerce & SEO Stratégique', professorName: 'Prof. Dubois', dayOfWeek: 'Jeudi', startTime: '14:00', endTime: '16:00', room: 'Lab Digital 405', color: 'emerald', filiere: 'marketing' },
  { id: 't11', courseTitle: 'Réseaux Sociaux & Content Strategy', professorName: 'Prof. Dubois', dayOfWeek: 'Vendredi', startTime: '13:00', endTime: '15:00', room: 'Lab Digital 405', color: 'emerald', filiere: 'marketing' }
];

const DEFAULT_ATTENDANCES: AttendanceRecord[] = [
  { id: 'a1', userId: 'student1', userName: 'Pierre Martin', date: '21 Mai 2026', courseTitle: 'Conception Web (React)', status: 'present', signed: true, timeSigned: '09:03 UTC' },
  { id: 'a2', userId: 'student1', userName: 'Pierre Martin', date: '22 Mai 2026', courseTitle: 'Backend & APIs (Express/Node)', status: 'late', signed: true, timeSigned: '14:14 UTC' },
  { id: 'a3', userId: 'student1', userName: 'Pierre Martin', date: '25 Mai 2026', courseTitle: 'Marketing & Stratégie', status: 'absent', signed: false },
  { id: 'a4', userId: 'student1', userName: 'Pierre Martin', date: '29 Mai 2026', courseTitle: 'Introduction à l\'Intelligence Artificielle', status: 'present', signed: false }
];

const DEFAULT_RECEIPTS: Receipt[] = [
  { id: 'rcpt1', paymentId: 'pay1', userId: 'student1', userName: 'Pierre Martin', amount: 2500, date: '28 Mai 2026', receiptNumber: 'RE-2026-0001', courseTitle: 'Informatique & Génie Logiciel', paymentMethod: 'Carte Bleue (Visa **** 4970)' }
];

// --- Local File Storage Logic ---
interface LocalStoreSchema {
  users: any[];
  formations: Formation[];
  candidatures: Candidature[];
  messages: Message[];
  payments: Payment[];
  timetable: TimetableEvent[];
  attendance: AttendanceRecord[];
  receipts: Receipt[];
}

async function readLocalStore(): Promise<LocalStoreSchema> {
  try {
    const raw = await fs.readFile(DATA_FILE, 'utf-8');
    const store = JSON.parse(raw);
    
    // Self healing if schema was parsed without new fields
    let updated = false;
    if (!store.timetable) {
      store.timetable = DEFAULT_TIMETABLES;
      updated = true;
    }
    if (!store.attendance) {
      store.attendance = DEFAULT_ATTENDANCES;
      updated = true;
    }
    if (!store.receipts) {
      store.receipts = DEFAULT_RECEIPTS;
      updated = true;
    }
    if (updated) {
      await writeLocalStore(store);
    }
    return store;
  } catch (err) {
    // If file doesn't exist, seed and save
    const defaultStore: LocalStoreSchema = {
      users: DEFAULT_USERS,
      formations: DEFAULT_FORMATIONS,
      candidatures: DEFAULT_CANDIDATURES,
      messages: DEFAULT_MESSAGES,
      payments: DEFAULT_PAYMENTS,
      timetable: DEFAULT_TIMETABLES,
      attendance: DEFAULT_ATTENDANCES,
      receipts: DEFAULT_RECEIPTS,
    };
    await writeLocalStore(defaultStore);
    return defaultStore;
  }
}

async function writeLocalStore(store: LocalStoreSchema): Promise<void> {
  await fs.writeFile(DATA_FILE, JSON.stringify(store, null, 2), 'utf-8');
}

// --- MONGOOSE SCHEMAS & MODELS (Conditionally Registered) ---
const UserSchema = new mongoose.Schema({
  id: { type: String, unique: true },
  nom: String,
  prenom: String,
  email: { type: String, unique: true },
  telephone: String,
  password: { type: String, select: false },
  role: { type: String, enum: ['student', 'admin'], default: 'student' },
  dateInscription: { type: String, default: () => new Date().toISOString() },
  formationsInscrites: [
    {
      formationId: Number,
      modules: [{ nom: String, progression: Number }]
    }
  ]
});

const FormationSchema = new mongoose.Schema({
  id: { type: Number, unique: true },
  titre: String,
  description: String,
  prix: Number,
  duree: String,
  niveau: String,
  image: String,
  categorie: String,
  modules: [{ nom: String, progression: Number }]
});

const CandidatureSchema = new mongoose.Schema({
  id: { type: String, unique: true },
  userId: String,
  nom: String,
  prenom: String,
  email: String,
  formation: String,
  niveau: String,
  statut: { type: String, enum: ['en_attente', 'admis', 'refuse'], default: 'en_attente' },
  lettre: String,
  cvUrl: String,
  date: { type: String, default: () => new Date().toISOString() }
});

const MessageSchema = new mongoose.Schema({
  id: { type: String, unique: true },
  senderName: String,
  senderRole: { type: String, enum: ['student', 'tutor'] },
  receiverName: String,
  text: String,
  date: { type: String, default: () => new Date().toISOString() }
});

const PaymentSchema = new mongoose.Schema({
  id: { type: String, unique: true },
  userId: String,
  formationId: Number,
  amount: Number,
  date: { type: String, default: () => new Date().toISOString() },
  status: { type: String, default: 'completed' }
});

let UserModel: mongoose.Model<any>;
let FormationModel: mongoose.Model<any>;
let CandidatureModel: mongoose.Model<any>;
let MessageModel: mongoose.Model<any>;
let PaymentModel: mongoose.Model<any>;

// --- Connect to MongoDB database if URI exists ---
export async function initDatabase() {
  if (MONGO_URI) {
    try {
      console.log('Attempting connection to MongoDB at:', MONGO_URI.substring(0, 25) + '...');
      await mongoose.connect(MONGO_URI, { connectTimeoutMS: 5000 });
      dbConfig = {
        type: 'MongoDB',
        status: 'connected',
        uri: MONGO_URI
      };
      console.log('MongoDB successfully connected!');

      UserModel = mongoose.models.User || mongoose.model('User', UserSchema);
      FormationModel = mongoose.models.Formation || mongoose.model('Formation', FormationSchema);
      CandidatureModel = mongoose.models.Candidature || mongoose.model('Candidature', CandidatureSchema);
      MessageModel = mongoose.models.Message || mongoose.model('Message', MessageSchema);
      PaymentModel = mongoose.models.Payment || mongoose.model('Payment', PaymentSchema);

      // Seed database with values if empty
      const userCount = await UserModel.countDocuments();
      if (userCount === 0) {
        console.log('Seeding MongoDB default collections...');
        await UserModel.insertMany(DEFAULT_USERS);
        await FormationModel.insertMany(DEFAULT_FORMATIONS);
        await CandidatureModel.insertMany(DEFAULT_CANDIDATURES);
        await MessageModel.insertMany(DEFAULT_MESSAGES);
        await PaymentModel.insertMany(DEFAULT_PAYMENTS);
      }
    } catch (err: any) {
      console.error('Failed to connect to MongoDB, falling back to Local JSON Files:', err.message);
      dbConfig = {
        type: 'LocalJSON',
        status: 'connected',
        error: err.message
      };
    }
  } else {
    console.log('No MONGO_URI environment variable set. Running with Local JSON file persistence.');
    dbConfig = {
      type: 'LocalJSON',
      status: 'connected'
    };
    // Make sure data is seeded
    await readLocalStore();
  }
}

// --- DATABASE ACCESSORS (Works on MongoDB or local JSON gracefully) ---

// 1. Users
export async function getUsers(): Promise<any[]> {
  if (dbConfig.type === 'MongoDB' && UserModel) {
    return await UserModel.find().lean();
  } else {
    const store = await readLocalStore();
    return store.users;
  }
}

export async function findUserByEmail(email: string): Promise<any | null> {
  if (dbConfig.type === 'MongoDB' && UserModel) {
    return await UserModel.findOne({ email }).select('+password').lean() as any;
  } else {
    const store = await readLocalStore();
    const user = store.users.find(u => u.email.toLowerCase() === email.toLowerCase());
    return user || null;
  }
}

export async function createUser(userData: any): Promise<any> {
  const newUser = {
    id: userData.id || 'user_' + Date.now(),
    nom: userData.nom,
    prenom: userData.prenom,
    email: userData.email,
    telephone: userData.telephone || '',
    password: userData.password,
    role: userData.role || 'student',
    dateInscription: new Date().toISOString(),
    formationsInscrites: userData.formationsInscrites || []
  };

  if (dbConfig.type === 'MongoDB' && UserModel) {
    const doc = new UserModel(newUser);
    await doc.save();
    return doc.toObject();
  } else {
    const store = await readLocalStore();
    store.users.push(newUser);
    await writeLocalStore(store);
    return newUser;
  }
}

// 2. Formations
export async function getFormations(userId?: string): Promise<Formation[]> {
  let list: Formation[] = [];

  if (dbConfig.type === 'MongoDB' && FormationModel) {
    list = await FormationModel.find().lean() as any[];
  } else {
    const store = await readLocalStore();
    list = store.formations;
  }

  // If a student userId is provided, inject their actual module progressions
  if (userId) {
    let student: any = null;
    if (dbConfig.type === 'MongoDB' && UserModel) {
      student = await UserModel.findOne({ id: userId }).lean();
    } else {
      const store = await readLocalStore();
      student = store.users.find(u => u.id === userId);
    }

    if (student && student.formationsInscrites) {
      return list.map(f => {
        const enrollment = student.formationsInscrites.find((e: any) => Number(e.formationId) === Number(f.id));
        if (enrollment) {
          return {
            ...f,
            modules: f.modules.map(mod => {
              const studentMod = enrollment.modules.find((m: any) => m.nom === mod.nom);
              return {
                nom: mod.nom,
                progression: studentMod ? studentMod.progression : 0
              };
            })
          };
        }
        return f;
      });
    }
  }

  return list;
}

export async function createFormation(formationData: any): Promise<Formation> {
  const store = await readLocalStore();
  const nextId = store.formations.length > 0 ? Math.max(...store.formations.map(f => Number(f.id) || 0)) + 1 : 1;
  const newFormation: Formation = {
    id: nextId,
    titre: formationData.titre,
    description: formationData.description || "",
    prix: Number(formationData.prix) || 2000,
    duree: formationData.duree || '3 ans',
    niveau: formationData.niveau || 'Licence',
    image: formationData.image || '📚',
    categorie: formationData.categorie || 'informatique',
    modules: (formationData.modules || []).map((m: any) => ({
      nom: typeof m === 'string' ? m : m.nom,
      progression: 0
    }))
  };

  if (dbConfig.type === 'MongoDB' && FormationModel) {
    const doc = new FormationModel(newFormation);
    await doc.save();
    return doc.toObject();
  } else {
    store.formations.push(newFormation);
    await writeLocalStore(store);
    return newFormation;
  }
}

export async function enrollInCourse(userId: string, formationId: number): Promise<void> {
  // Fetch default modules for this formation
  let formation: Formation | null = null;
  if (dbConfig.type === 'MongoDB' && FormationModel) {
    formation = await FormationModel.findOne({ id: formationId }).lean() as any;
  } else {
    const store = await readLocalStore();
    formation = store.formations.find(f => Number(f.id) === Number(formationId)) || null;
  }

  if (!formation) throw new Error('Formation introuvable');

  const defaultEnrollment = {
    formationId: formationId,
    modules: formation.modules.map(m => ({ nom: m.nom, progression: 0 }))
  };

  if (dbConfig.type === 'MongoDB' && UserModel) {
    await UserModel.updateOne(
      { id: userId },
      { $addToSet: { formationsInscrites: defaultEnrollment } }
    );
  } else {
    const store = await readLocalStore();
    const userIndex = store.users.findIndex(u => u.id === userId);
    if (userIndex !== -1) {
      const user = store.users[userIndex];
      user.formationsInscrites = user.formationsInscrites || [];
      const alreadyIn = user.formationsInscrites.some((e: any) => Number(e.formationId) === Number(formationId));
      if (!alreadyIn) {
        user.formationsInscrites.push(defaultEnrollment);
        await writeLocalStore(store);
      }
    }
  }
}

export async function updateModuleProgress(userId: string, formationId: number, moduleName: string, progression: number): Promise<void> {
  if (dbConfig.type === 'MongoDB' && UserModel) {
    // Find customer document, then update appropriate array element
    await UserModel.updateOne(
      { id: userId, "formationsInscrites.formationId": formationId, "formationsInscrites.modules.nom": moduleName },
      { $set: { "formationsInscrites.$[outer].modules.$[inner].progression": progression } },
      {
        arrayFilters: [
          { "outer.formationId": formationId },
          { "inner.nom": moduleName }
        ]
      }
    );
  } else {
    const store = await readLocalStore();
    const userIndex = store.users.findIndex(u => u.id === userId);
    if (userIndex !== -1) {
      const user = store.users[userIndex];
      user.formationsInscrites = user.formationsInscrites || [];
      const enrollment = user.formationsInscrites.find((e: any) => Number(e.formationId) === Number(formationId));
      if (enrollment) {
        const mod = enrollment.modules.find((m: any) => m.nom === moduleName);
        if (mod) {
          mod.progression = progression;
          await writeLocalStore(store);
        }
      }
    }
  }
}

// 3. Candidatures (Admissions)
export async function getCandidatures(userId?: string): Promise<Candidature[]> {
  if (dbConfig.type === 'MongoDB' && CandidatureModel) {
    const query = userId ? { userId } : {};
    return await CandidatureModel.find(query).sort({ date: -1 }).lean() as any[];
  } else {
    const store = await readLocalStore();
    if (userId) {
      return store.candidatures.filter(c => c.userId === userId);
    }
    return store.candidatures;
  }
}

export async function createCandidature(candData: any): Promise<Candidature> {
  const newCand: Candidature = {
    id: 'cand_' + Date.now(),
    userId: candData.userId,
    nom: candData.nom,
    prenom: candData.prenom,
    email: candData.email,
    formation: candData.formation,
    niveau: candData.niveau,
    statut: candData.statut || 'en_attente',
    lettre: candData.lettre || '',
    cvUrl: candData.cvUrl || '',
    date: new Date().toISOString()
  };

  if (dbConfig.type === 'MongoDB' && CandidatureModel) {
    const doc = new CandidatureModel(newCand);
    await doc.save();
    return doc.toObject();
  } else {
    const store = await readLocalStore();
    store.candidatures.push(newCand);
    await writeLocalStore(store);
    return newCand;
  }
}

export async function updateCandidatureStatus(id: string, statut: 'en_attente' | 'admis' | 'refuse'): Promise<Candidature | null> {
  if (dbConfig.type === 'MongoDB' && CandidatureModel) {
    const updated = await CandidatureModel.findOneAndUpdate({ id }, { statut }, { new: true }).lean();
    if (updated && statut === 'admis') {
      // If student is admitted, check and enroll them instantly in the corresponding course if course details match
      // Translate selected database slug to formation ID
      let courseId = 1;
      const slug = updated.formation.toLowerCase();
      if (slug.includes('gestion')) courseId = 2;
      else if (slug.includes('droit')) courseId = 3;
      else if (slug.includes('marketing')) courseId = 4;
      else if (slug.includes('data')) courseId = 5;
      try {
        await enrollInCourse(updated.userId, courseId);
      } catch (err) {
        console.error('Auto course registration failed during admission status change:', err);
      }
    }
    return updated as any;
  } else {
    const store = await readLocalStore();
    const candIndex = store.candidatures.findIndex(c => c.id === id);
    if (candIndex !== -1) {
      const updated = { ...store.candidatures[candIndex], statut };
      store.candidatures[candIndex] = updated;

      if (statut === 'admis') {
        let courseId = 1;
        const slug = updated.formation.toLowerCase();
        if (slug.includes('gestion')) courseId = 2;
        else if (slug.includes('droit')) courseId = 3;
        else if (slug.includes('marketing')) courseId = 4;
        else if (slug.includes('data')) courseId = 5;
        try {
          const userIndex = store.users.findIndex(u => u.id === updated.userId);
          if (userIndex !== -1) {
            const user = store.users[userIndex];
            user.formationsInscrites = user.formationsInscrites || [];
            const formation = store.formations.find(f => Number(f.id) === Number(courseId));
            if (formation) {
              const alreadyIn = user.formationsInscrites.some((e: any) => Number(e.formationId) === Number(courseId));
              if (!alreadyIn) {
                user.formationsInscrites.push({
                  formationId: courseId,
                  modules: formation.modules.map(m => ({ nom: m.nom, progression: 0 }))
                });
              }
            }
          }
        } catch (err) {
          console.error('Auto local course registration failed during local admission status change:', err);
        }
      }

      await writeLocalStore(store);
      return updated;
    }
    return null;
  }
}

// 4. Messages (Chat)
export async function getMessages(userId: string): Promise<Message[]> {
  // Let's retrieve all messages exchanged with this user.
  // Their receiverName is either 'ELSON Jacquecin Grela' or they are standard tutors messaging the user
  if (dbConfig.type === 'MongoDB' && MessageModel) {
    // Get messages where senderName is the user or receiverName is the user
    // To make things simple, we'll retrieve all messages for that workspace
    return await MessageModel.find().sort({ date: 1 }).lean() as any[];
  } else {
    const store = await readLocalStore();
    return store.messages;
  }
}

export async function createMessage(msgData: any): Promise<Message> {
  const newMsg: Message = {
    id: 'msg_' + Date.now(),
    senderName: msgData.senderName,
    senderRole: msgData.senderRole,
    receiverName: msgData.receiverName,
    text: msgData.text,
    date: new Date().toISOString()
  };

  if (dbConfig.type === 'MongoDB' && MessageModel) {
    const doc = new MessageModel(newMsg);
    await doc.save();
    return doc.toObject();
  } else {
    const store = await readLocalStore();
    store.messages.push(newMsg);
    await writeLocalStore(store);
    return newMsg;
  }
}

// 5. Payments
export async function getPayments(): Promise<Payment[]> {
  if (dbConfig.type === 'MongoDB' && PaymentModel) {
    return await PaymentModel.find().sort({ date: -1 }).lean() as any[];
  } else {
    const store = await readLocalStore();
    return store.payments;
  }
}

export async function createPayment(payData: any): Promise<Payment> {
  const newPay: Payment = {
    id: 'pay_' + Date.now(),
    userId: payData.userId,
    formationId: Number(payData.formationId),
    amount: Number(payData.amount),
    date: new Date().toISOString(),
    status: 'completed'
  };

  if (dbConfig.type === 'MongoDB' && PaymentModel) {
    const doc = new PaymentModel(newPay);
    await doc.save();

    // Auto-enroll the user upon successful payment
    try {
      await enrollInCourse(payData.userId, Number(payData.formationId));
    } catch (err) {
      console.error('Course auto-enrollment error upon Mongo payment:', err);
    }
    return doc.toObject();
  } else {
    const store = await readLocalStore();
    store.payments.push(newPay);

    // Get user details for the receipt
    const userObj = store.users.find(u => u.id === payData.userId);
    const uName = userObj ? `${userObj.prenom} ${userObj.nom}` : "Élève Unive";
    
    // Get course title
    const formation = store.formations.find(f => Number(f.id) === Number(payData.formationId));
    const cTitle = formation ? formation.titre : "Licence Génie Logiciel";

    // Auto-generate detailed receipt
    const randNum = Math.floor(1000 + Math.random() * 9000);
    const receiptNumber = `RE-2026-${randNum}`;
    const newReceipt: Receipt = {
      id: 'rcpt_' + Date.now(),
      paymentId: newPay.id,
      userId: payData.userId,
      userName: uName,
      amount: Number(payData.amount),
      date: new Date().toLocaleDateString('fr-FR', { year: 'numeric', month: 'long', day: 'numeric' }),
      receiptNumber,
      courseTitle: cTitle,
      paymentMethod: 'Carte Bleue (Visa/Mastercard)'
    };
    store.receipts = store.receipts || [];
    store.receipts.push(newReceipt);

    // Auto-enroll
    try {
      const userIndex = store.users.findIndex(u => u.id === payData.userId);
      if (userIndex !== -1) {
        const user = store.users[userIndex];
        user.formationsInscrites = user.formationsInscrites || [];
        const alreadyIn = user.formationsInscrites.some((e: any) => Number(e.formationId) === Number(payData.formationId));
        if (!alreadyIn) {
          if (formation) {
            user.formationsInscrites.push({
              formationId: Number(payData.formationId),
              modules: formation.modules.map(m => ({ nom: m.nom, progression: 0 }))
            });
          }
        }
      }
    } catch (err) {
      console.error('Course auto-enrollment error upon Local payment:', err);
    }

    await writeLocalStore(store);
    return newPay;
  }
}

// 6. Stats aggregator
export async function getDashboardStats(): Promise<DashboardStats> {
  const users = await getUsers();
  const candidatures = await getCandidatures();
  const payments = await getPayments();

  const totalEtudiants = users.filter(u => u.role === 'student').length;
  const totalCandidatures = candidatures.length;
  const enAttente = candidatures.filter(c => c.statut === 'en_attente').length;
  const totalAdmis = candidatures.filter(c => c.statut === 'admis').length;

  // Let's count certifications (courses completely finished with 100% progress)
  let totalCertifies = 0;
  for (const user of users) {
    if (user.formationsInscrites) {
      for (const course of user.formationsInscrites) {
        if (course.modules && course.modules.length > 0) {
          const isComplete = course.modules.every((m: any) => m.progression === 100);
          if (isComplete) totalCertifies++;
        }
      }
    }
  }

  // Revenues: sum of completed payments amount
  const totalRevenus = payments.reduce((sum, p) => sum + p.amount, 0);

  return {
    totalEtudiants,
    totalCandidatures,
    totalAdmis,
    totalCertifies,
    totalRevenus,
    enAttente
  };
}

// 7. Timetables
export async function getTimetable(): Promise<TimetableEvent[]> {
  const store = await readLocalStore();
  return store.timetable || DEFAULT_TIMETABLES;
}

export async function createTimetableEvent(eventData: Omit<TimetableEvent, 'id'>): Promise<TimetableEvent> {
  const store = await readLocalStore();
  const newEvent: TimetableEvent = {
    id: 't_' + Date.now(),
    ...eventData
  };
  store.timetable = store.timetable || [];
  store.timetable.push(newEvent);
  await writeLocalStore(store);
  return newEvent;
}

export async function deleteTimetableEvent(id: string): Promise<boolean> {
  const store = await readLocalStore();
  store.timetable = store.timetable || [...DEFAULT_TIMETABLES];
  const initialLength = store.timetable.length;
  store.timetable = store.timetable.filter(item => item.id !== id);
  await writeLocalStore(store);
  return store.timetable.length < initialLength;
}

// 8. Attendance
export async function getAttendance(userId?: string): Promise<AttendanceRecord[]> {
  const store = await readLocalStore();
  const list = store.attendance || DEFAULT_ATTENDANCES;
  if (userId) {
    return list.filter(a => a.userId === userId);
  }
  return list;
}

export async function signAttendance(recordId: string, timeSigned: string, status?: 'present' | 'absent' | 'late'): Promise<AttendanceRecord | null> {
  const store = await readLocalStore();
  store.attendance = store.attendance || [];
  const idx = store.attendance.findIndex(a => a.id === recordId);
  if (idx !== -1) {
    store.attendance[idx].signed = true;
    store.attendance[idx].timeSigned = timeSigned;
    if (status) {
      store.attendance[idx].status = status;
    } else {
      store.attendance[idx].status = 'present';
    }
    await writeLocalStore(store);
    return store.attendance[idx];
  }
  return null;
}

export async function createAttendanceRecord(recordData: Omit<AttendanceRecord, 'id'>): Promise<AttendanceRecord> {
  const store = await readLocalStore();
  const newRecord: AttendanceRecord = {
    id: 'a_' + Date.now(),
    ...recordData
  };
  store.attendance = store.attendance || [];
  store.attendance.push(newRecord);
  await writeLocalStore(store);
  return newRecord;
}

// 9. Receipts
export async function getReceipts(userId?: string): Promise<Receipt[]> {
  const store = await readLocalStore();
  const list = store.receipts || DEFAULT_RECEIPTS;
  if (userId) {
    return list.filter(r => r.userId === userId);
  }
  return list;
}

export async function createReceipt(receiptData: Omit<Receipt, 'id' | 'receiptNumber'>): Promise<Receipt> {
  const store = await readLocalStore();
  const randNum = Math.floor(1000 + Math.random() * 9000);
  const receiptNumber = `RE-2026-${randNum}`;
  const newReceipt: Receipt = {
    id: 'rcpt_' + Date.now(),
    receiptNumber,
    ...receiptData
  };
  store.receipts = store.receipts || [];
  store.receipts.push(newReceipt);
  await writeLocalStore(store);
  return newReceipt;
}
